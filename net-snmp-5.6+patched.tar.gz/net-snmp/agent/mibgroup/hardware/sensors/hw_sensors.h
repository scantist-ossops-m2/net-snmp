void init_hw_sensors( void );
