/*
 *  Host Resources MIB - Running Software group interface - hr_swinst.h
 *
 */
#ifndef _MIBGROUP_HRSWINST_H
#define _MIBGROUP_HRSWINST_H

extern void     init_hr_swinst(void);
extern FindVarMethod var_hrswinst;


#endif                          /* _MIBGROUP_HRSWINST_H */
