void init_cpu(void);
