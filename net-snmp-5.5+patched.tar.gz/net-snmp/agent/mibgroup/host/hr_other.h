/*
 *  Host Resources MIB - other devices interface - hr_other.h
 *
 */
#ifndef _MIBGROUP_HROTHER_H
#define _MIBGROUP_HROTHER_H

config_require(host/hr_device)

void            init_hr_other(void);

#endif /* _MIBGROUP_HROTHER_H */
