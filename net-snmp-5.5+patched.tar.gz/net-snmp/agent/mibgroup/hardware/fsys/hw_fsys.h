void init_fsys(void);
